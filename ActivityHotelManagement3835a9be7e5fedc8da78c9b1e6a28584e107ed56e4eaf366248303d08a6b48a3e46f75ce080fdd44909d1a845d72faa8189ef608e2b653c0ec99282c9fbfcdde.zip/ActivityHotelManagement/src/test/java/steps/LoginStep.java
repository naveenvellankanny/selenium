package steps;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.HotelLoginPage;


import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep {

	WebDriver driver;
	
	HotelLoginPage page;
	
	@Before
	public void setUp() {

		driver = BrowserFactory.startBrowser("chrome",
				"D:\\AaaaaModule4\\ActivityHotelManagement\\src\\test\\java\\html\\login.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}
	
	@Given("^User is on Welcome to HotelPage page$")
	public void user_is_on_Welcome_to_HotelPage_page() throws Throwable {
		page = PageFactory.initElements(driver, HotelLoginPage.class);
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		assertEquals("Hotel Booking Application", page.getHeading());
		if (page.getHeading().equals("Hotel Booking Application")) {
			System.out.println("Heading matched");
		} else {
			System.out.println("Heading not matched");
		}
	}

	@Given("^User is on welcome Page$")
	public void user_is_on_welcome_Page() throws Throwable {
		page = PageFactory.initElements(driver, HotelLoginPage.class);
	}

	@When("^User leaves username empty$")
	public void user_leaves_username_empty() throws Throwable {
		page.setUsername("");
		page.setPassword("capg1234");
		page.setLogin();
	}

	@When("^Clicks the login button$")
	public void clicks_the_login_button() throws Throwable {
	
	}

	@Then("^Display username Alert msg$")
	public void display_username_Alert_msg() throws Throwable {
		

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		
		
		if (page.getUserErrMsg().equals("* Please enter userName.")) {
			System.out.println("The text msg on alert box is: " + page.getUserErrMsg());
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		
	}

	@When("^User leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		page.setUsername("Capgemini");
		page.setPassword("");
		page.setLogin();
	}

	@Then("^Display password Alert msg$")
	public void display_password_Alert_msg() throws Throwable {

		if (page.getPwdErrMsg().equals("* Please enter password.")) {
			System.out.println("The text msg on alert box is: " + page.getPwdErrMsg());
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		
	}

	@When("^User enters UserName and Password$")
	public void user_enters_UserName_and_Password() throws Throwable {
		page.setUsername("capgemini");
		page.setPassword("capg1234");
		page.setLogin();
	}

	@Then("^Message displayed Login Successfully$")
	public void message_displayed_Login_Successfully() throws Throwable {
		System.out.println("Login successful");
		//driver.navigate().to("D:\\AaaaaModule4\\ActivityHotelManagement\\src\\test\\java\\html\\hotelbooking.html");
	}
}
